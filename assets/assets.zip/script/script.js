        /*homepage counter*/

        	$(window).scroll(function () {
        
        		$('.counter').each(function() {
        			var $this = $(this),
        				countTo = $this.attr('data-number');
        
        			$({ countNum: $this.text()}).animate({
        				countNum: countTo
        			},
        												 {
        				duration: 3000,
        				easing:'linear',
        				step: function() {
        					$this.text(Math.floor(this.countNum));
        				},
        				complete: function() {
        					$this.text(this.countNum);
        				}
        			});
        		});
        
        	});
        	
        	/*homepage counter end*/
        	
        	
        /* Model Care Script */
        $(document).ready(function () {
  var time = 3;
  var isPause,
    tick,
    percentTime;
  var $bar = $('.slide_progress .progress');
  var $status = $('.slide_wrap .slide_paging');
  var $navTabs = $("#modelCareTab button");

  $navTabs.on('shown.bs.tab', function(event) {
    var currentTab = $(event.target).attr('href');
    $(currentTab).addClass("show active");
    $status.html('<span class="count">' + ($(event.target).index() + 1) + '</span> / <span class="pagecount">' + $navTabs.length + '</span>');
  });

  $navTabs.on('hide.bs.tab', function(event) {
    var currentTab = $(event.target).attr('href');
    $(currentTab).removeClass("show active");
  });

  // Navigation controls
  $(document).ready(function () {
  var time = 3;
  var isPause,
    tick,
    percentTime;
  var $bar = $('.slide_progress .progress');
  var $status = $('.slide_wrap .slide_paging');
  var $navTabs = $("#modelCareTab button");

  $navTabs.on('shown.bs.tab', function(event) {
    var currentTab = $(event.target).attr('href');
    $(currentTab).addClass("show active");
    $status.html('<span class="count">' + ($(event.target).index() + 1) + '</span> / <span class="pagecount">' + $navTabs.length + '</span>');
  });

  $navTabs.on('hide.bs.tab', function(event) {
    var currentTab = $(event.target).attr('href');
    $(currentTab).removeClass("show active");
  });

  // Navigation controls
  $(".btn_playcontrol").click(function(){
    if($(this).hasClass("pause")){
      $(this).removeClass("pause")
      isPause = true;
    }else{
      $(this).addClass("pause")
      isPause = false;
    }
  })

  function startProgressbar() {
    resetProgressbar();
    percentTime = 0;
    isPause = false;
    tick = setInterval(interval, 10);
  }

  function interval() {
    if (isPause === false) {
      percentTime += 1 / (time + 0.1);
      $bar.css({
        width: percentTime + "%"
      });
      if (percentTime >= 100) {
        var currentIndex = $navTabs.index($navTabs.filter('.active'));
        var nextIndex = (currentIndex + 1) % $navTabs.length;
        $navTabs.eq(nextIndex).tab('show');
        startProgressbar();
      }
    }
  }

  function resetProgressbar() {
    $bar.css({
      width: 0 + '%'
    });
    clearTimeout(tick);
  }

  startProgressbar();

  $('.btn_prev').click(function() {
    var currentIndex = $navTabs.index($navTabs.filter('.active'));
    var prevIndex = (currentIndex - 1 + $navTabs.length) % $navTabs.length;
    $navTabs.eq(prevIndex).tab('show');
    if ($(".btn_playcontrol").hasClass("pause")){
      startProgressbar();
    } 
  });

  $('.btn_next').click(function() {
    var currentIndex = $navTabs.index($navTabs.filter('.active'));
    var nextIndex = (currentIndex + 1) % $navTabs.length;
    $navTabs.eq(nextIndex).tab('show');
    if ($(".btn_playcontrol").hasClass("pause")){
      startProgressbar();
    }
  });
});


            /* Model Script End */









            /* Model script */
            $('.inner_story_box').on('click', function() {
              var videoSrc = $(this).find('video').children('source').attr('src');
              $('#testimonialModal iframe').attr('src', videoSrc + 'autoplay=1');
              $('#testimonialModal').modal('show');
            });
            
            
            /* Select Filter */
        
        $(function () {
            $('#filter_department').on('change', function() {
                var selectedDepartment = $(this).val().toLowerCase();
                
                if (selectedDepartment === 'all') {
                    $('.doctor_box').show();
                } else {
                    $('.doctor_box').each(function() {
                        var $doctorBox = $(this);
                        var postText = $doctorBox.find('.post p').text().toLowerCase();
                        
                        if (postText.includes(selectedDepartment)) {
                            $doctorBox.show();
                        } else {
                            $doctorBox.hide();
                        }
                    });
                }
            });
        });

        
        // $(function () {
        //     $('#filter_speciality').on('change', function() {
        //         var selectedCategory = $(this).val();
                
        //         if (selectedCategory === 'all') {
        //             $('.doctors_container .doctor_box').show();
        //         } else {
        //             $('.doctors_container .doctor_box').each(function() {
        //                 var $doctorBox = $(this);
        //                 if ($doctorBox.data('category') === selectedCategory) {
        //                     $doctorBox.show();
        //                 } else {
        //                     $doctorBox.hide();
        //                 }
        //             });
        //         }
        //     });
        // });

        
        
        // $(function () {
        //     $('#filter_clinics').on('change', function() {
        //         var selectedCategory = $(this).val();
                
        //         if (selectedCategory === 'all') {
        //             $('.doctors_container .doctor_box').show();
        //         } else {
        //             $('.doctors_container .doctor_box').each(function() {
        //                 var $doctorBox = $(this);
        //                 if ($doctorBox.data('category') === selectedCategory) {
        //                     $doctorBox.show();
        //                 } else {
        //                     $doctorBox.hide();
        //                 }
        //             });
        //         }
        //     });
        // });
        
        
        /* End Here */


        
        